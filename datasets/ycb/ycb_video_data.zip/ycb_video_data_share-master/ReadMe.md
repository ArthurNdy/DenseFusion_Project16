Tried to upload a short version of the ycb_video dataset as requested in https://github.com/yuxng/PoseCNN/issues/81
I could not upload the "models" directory. Tried to upload them but couldn't. Could only upload "002_master_chef_can" which was originally inside "models" folder. However, inside "002_master_chef_can" couldn't upload the "textured.obj" as the file size is too big.

Will try to upload them later if needed.
